import React from 'react';
import { 
  X, 
  Terminal, 
  Smartphone, 
  KeyRound, 
  ShieldAlert, 
  Code2, 
  Sliders, 
  Database, 
  FileCode2, 
  ExternalLink,
  Volume2
} from 'lucide-react';
import { ScreenId } from '../types';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeScreen: ScreenId;
  onSelectScreen: (screen: ScreenId) => void;
  voicePersona: 'Charon' | 'Fenrir';
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  activeScreen,
  onSelectScreen,
  voicePersona,
}) => {
  if (!isOpen) return null;

  const menuItems: Array<{ id: ScreenId; label: string; icon: React.ReactNode; badge?: string; desc: string }> = [
    {
      id: 'home',
      label: 'Neural Chat Terminal',
      icon: <Terminal className="w-4 h-4 text-cyan-400" />,
      desc: 'Real-time text & voice conversation with VOID'
    },
    {
      id: 'automation',
      label: 'Screen Automation & Gestures',
      icon: <Smartphone className="w-4 h-4 text-emerald-400" />,
      badge: 'Core',
      desc: 'Read screen, click buttons, type text, launch apps'
    },
    {
      id: 'permissions',
      label: 'Android OS Permissions',
      icon: <ShieldAlert className="w-4 h-4 text-amber-400" />,
      badge: 'Required',
      desc: 'Mic, Camera, Accessibility, Always-on Foreground Service'
    },
    {
      id: 'apisettings',
      label: 'Gemini API Key & Voice',
      icon: <KeyRound className="w-4 h-4 text-cyan-400" />,
      desc: 'API Key storage, deep voice pitch, speech testing'
    },
    {
      id: 'codestudio',
      label: 'AI Code & Script Studio',
      icon: <Code2 className="w-4 h-4 text-purple-400" />,
      desc: 'Autonomous script generator & sandbox runner'
    },
    {
      id: 'macros',
      label: 'Voice Macro Manager',
      icon: <Sliders className="w-4 h-4 text-pink-400" />,
      desc: 'Custom multi-step voice command sequences'
    },
    {
      id: 'androidsource',
      label: 'Android Project & APK Build',
      icon: <FileCode2 className="w-4 h-4 text-cyan-400" />,
      badge: 'ZIP Ready',
      desc: 'Capacitor Android source, Kotlin services, GitHub Actions'
    },
    {
      id: 'memory',
      label: 'Neural Context Memory',
      icon: <Database className="w-4 h-4 text-zinc-400" />,
      desc: 'Session telemetry, interaction cache, and memory dump'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/85 backdrop-blur-md transition-opacity"
        onClick={onClose} 
      />

      {/* Drawer Panel */}
      <aside className="relative z-10 w-full max-w-xs sm:max-w-sm bg-[#08080c] border-r border-white/10 h-full flex flex-col justify-between p-5 text-white shadow-2xl">
        
        {/* Header */}
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl overflow-hidden border border-cyan-400/60 shadow-[0_0_12px_rgba(0,240,255,0.4)]">
                <img 
                  src="/logo.jpg" 
                  alt="VØID.AI" 
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/src/assets/images/void_app_logo_1793162755394.jpg';
                  }}
                />
              </div>
              <div>
                <h2 className="text-lg font-bold font-display tracking-widest text-white">VØID.AI</h2>
                <div className="text-[10px] font-mono text-cyan-400">TACTICAL ANDROID SYSTEM</div>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-white/10 text-zinc-400 hover:text-white transition-all cursor-pointer"
              aria-label="Close Drawer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Items */}
          <nav className="mt-4 space-y-1.5 overflow-y-auto max-h-[calc(100vh-220px)] pr-1">
            {menuItems.map((item) => {
              const isActive = activeScreen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectScreen(item.id);
                    onClose();
                  }}
                  className={`w-full p-3 rounded-xl text-left transition-all flex items-start gap-3 group cursor-pointer ${
                    isActive
                      ? 'bg-cyan-950/50 border border-cyan-400/80 text-white shadow-[0_0_15px_rgba(0,240,255,0.15)]'
                      : 'bg-black/30 border border-transparent hover:border-white/10 hover:bg-zinc-900/50 text-zinc-300'
                  }`}
                >
                  <div className={`mt-0.5 p-1.5 rounded-lg border ${
                    isActive ? 'bg-cyan-500/20 border-cyan-400' : 'bg-zinc-900 border-white/10 group-hover:border-cyan-400/40'
                  }`}>
                    {item.icon}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-mono font-bold truncate ${isActive ? 'text-cyan-300' : 'text-white'}`}>
                        {item.label}
                      </span>
                      {item.badge && (
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-700/60 ml-2">
                          {item.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] font-mono text-zinc-500 mt-0.5 line-clamp-1">
                      {item.desc}
                    </p>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-white/10 flex flex-col gap-2">
          <div className="flex items-center justify-between text-[10px] font-mono text-zinc-500">
            <span>Voice Tone: <strong className="text-white">{voicePersona}</strong></span>
            <span className="text-cyan-400">v8.5.3 Native</span>
          </div>
          <div className="text-[9px] font-mono text-zinc-600 text-center">
            AMOLED Tactical OS • com.voidai.app
          </div>
        </div>

      </aside>
    </div>
  );
};
